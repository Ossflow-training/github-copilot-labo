# mysystem-copilot

Script Python qui décrit la machine : système d'exploitation, mémoire, interfaces réseau.

### Installation des dépendances

`pip install -r requirements-dev.txt`

### Lint

`pylint --disable=missing-docstring script/mysystem`

### Exécution

`python script/mysystem/mysystem.py`

### Tests unitaires

`pytest script/mysystem`
