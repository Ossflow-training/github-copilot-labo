# Welcome to Sysinfo documentation

# Gitlab-ci training

Setup CI/CD pipeline for sysinfo project

### mysystem (Python)
**Python script dependancies installation**

`pip install -r requirements.txt`

**Python script lint**

`pip install pylint`  
`pylint --disable=missing-docstring script/mysystem`

**Python script execution**

`python script/mysystem/mysystem.py`

**Python unit tests**

 `pytest --junitxml=report.xml script/mysystem`
