# About Sysinfo

Lab project for GitHub Copilot labs
